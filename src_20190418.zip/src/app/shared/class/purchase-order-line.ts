// export class PurchaseOrderLine {
//     constructor(
//         public PurchaseOrderLineID: number,
//         public PurchaseOrderID: number,
//         public ItemID: number,
//         public ItemName: string,
//         public ItemVendorSKU: string,
//         public TPIN: string,
//         public FOBPrice: number,
//         public Quantity: number,
//         public CartonQuantity: number,
//         public ReceivedQty: number,
//         public UpdatedOn: string,
//         public CreatedOn: string
//     ) {}
// }

// export class PurchaseOrderLineInsert {
//     constructor(
//         public PurchaseOrderID: number,
//         public ItemID: number,
//         public FOBPrice: number,
//         public Quantity: number
//     ) {}
// }

// export class PurchaseOrderLineUpdate {
//     constructor(
//         public ItemID: number,
//         public FOBPrice: number,
//         public Quantity: number
//     ) {}
// }


// export class PurchaseOrderLineList {
//     constructor(
//         public Value: number,
//         public Label: string,
//         public ItemName: string,
//         public VendorSKU: string,
//         public TPIN: string
//     ) {}
// }

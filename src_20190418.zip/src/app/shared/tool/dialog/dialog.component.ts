import { Component } from '@angular/core';


@Component({
  selector: 'o-dialog',
  templateUrl: 'dialog.component.html',
  styleUrls: ['dialog.component.css'],
})

export class DialogComponent {
    constructor() { }
}

import { Component } from '@angular/core';

@Component({
    selector: 'o-company-attachment',
    templateUrl: './company-attachment.component.html'
})

export class CompanyAttachmentComponent   {
    constructor() { }
}

export class VendorList {
    constructor(
        public VendorID: number,
        public Description: string,
        public VendorName: string
    ) {}
}

export class AddressCountry {
    constructor(
        public CountryID: string,
        public CountryName: string
    ) {}
}

export class AddressState {
    constructor(
        public StateID: string,
        public StateName: string
    ) {}
}